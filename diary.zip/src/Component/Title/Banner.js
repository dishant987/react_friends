import React from 'react';
import './Banner.css';
const Banner = () => {
  return (
    <div className='bannerStyle'>
      <h1>Friends Diary</h1>
      <h2>Welcome</h2>
    </div>
  )
}

export default Banner
