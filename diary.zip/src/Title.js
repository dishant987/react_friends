import React from "react";

class Title extends React.Component{
    render(){
        return(
            <div>
                this is a class componets
            </div>
        )
    }
}


export default Title;